class View {
  constructor(game, $el) {
    this.game = game;
    this.$el = $el;
    $el.append(this.setupBoard());
    this.bindEvents();
  }

  bindEvents() {
    let context = this;
    $('ul').on('click', "li", function(event){
      // debugger
      let $box = $(event.currentTarget);
      if (context.game.isOver()){
        return;
      }
      if (!$box.hasClass('unselected')){
        alert('invalid move, target square is already filled');
        return;
      }
      let pos = $box.data("pos");
      let mark = context.game.currentPlayer;
      $box.append(mark);
      context.game.playMove(pos);
      $box.removeClass("unselected");
      context.makeMove();
    });
  }

  makeMove() {
   if (this.game.isOver()) {
     //display winning message
    let $over_msg = $("<h1></h1>");

    if (this.game.winner()){
      $over_msg.append(`Winner: ${this.game.winner()}!`);
    } 
    else {
      $over_msg.append("It's a draw");
    }
    
    this.$el.append($over_msg);
    }
    
  }

  setupBoard() {
    let $grid = $('<ul></ul>');

    for (let row = 0; row < 3; row++){
      for (let col = 0; col < 3; col++){
        let $cell = $('<li></li>');
        $cell.data("pos", [row, col]);
        $cell.addClass("unselected");
        $grid.append($cell);
      }
    }
    return $grid;
  }
  
}

module.exports = View;
