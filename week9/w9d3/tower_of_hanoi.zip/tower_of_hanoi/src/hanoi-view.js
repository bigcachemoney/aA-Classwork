class View {
  constructor(game, $el) {
    this.game = game;
    this.$el = $el;
    this.setupTower();
    this.startTower = null;
    this.clickTower();
  }
  
  
  //In the constructor, install a click handler on each pile. I wrote a clickTower method.
  //On the first click to a pile, get the pile number and store this in an instance variable. 
  //On the second click (which you can identify because the ivar has been set), perform the move. Reset the ivar after. Alert the user if this was an invalid move.
  clickTower() {
    let context = this;
    $('ul').on('click', function (event) {
      let $target = $(event.currentTarget);

      if (context.startTower !== null){
        if (!context.game.move(context.startTower, $target.data('towerIdx'))){
          alert('Invalid move');
          
        } else {
          context.render(context.startTower, $target.data('towerIdx'));
        }
        $('ul').removeClass();
        context.startTower = null;
      }
      else {
        $target.addClass('selected');
        context.startTower = $target.data('towerIdx');
      }
    });
  }

  render(startIdx, endIdx) {
    $('ul')
  }

  setupTower() {
    for (let tower = 0; tower < 3; tower++) {
      let $tower = $('<ul></ul>');
      $tower.data('towerIdx', tower);

      for (let plate = 0; plate < 3; plate++) {
        let $plate = $('<li></li>');
        // $cell.data("pos", [tower, col]);
        if (tower === 0) {
          if (plate === 0){
            $plate.addClass("plate-1");
          }
          if (plate === 1){
            $plate.addClass("plate-2");
          }
          if (plate === 2){
            $plate.addClass("plate-3");
          }
        }
        
        $tower.append($plate);
      }
      this.$el.append($tower);
    }
  }
}

module.exports = View;

