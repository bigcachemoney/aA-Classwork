# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.
require 'byebug'

def prime(num)
    if num < 2
        return false
    end

    (2...num).each do |factor|
        if num % factor == 0
            return false
        end
    end
    true
end

def factors(num)
    (2..num).select {|factor| num % factor == 0}
end


def largest_prime_factor(num)
    factors(num).reverse.each do |number|
        if prime(number)
            return number
        end
    end 
end

def unique_chars?(str)
    hash = Hash.new(0)
    str.each_char do |char|
        hash[char] += 1
    end
    hash.each do |key, val|
        if val > 1
            return false
        end
    end
    return true
end

def dupe_indices(arr)
    hash = Hash.new([])

    arr.each_with_index do |char, idx|
        hash[char] += [idx]
    end
    hash.select{|key, val| val.length > 1}
end

def ana_array(arr1, arr2)
   # debugger
    if bubblesort(arr1) == bubblesort(arr2)
        return true
    end
    false
end

def bubblesort(arr)
    sorted = false

    while !sorted
        sorted = true
        (0...arr.length-1).each do |idx|
            if arr[idx] > arr[idx+1]
                sorted = false
                arr[idx], arr[idx+1] = arr[idx+1], arr[idx]
            end
        end
    end
    arr
end