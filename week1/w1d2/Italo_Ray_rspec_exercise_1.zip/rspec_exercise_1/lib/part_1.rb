def average(num1, num2)
    (num1 + num2)/2.0
end

def average_array(arr)
    arr.sum/arr.length.to_f
end

def repeat(str, num)
    new_str = ""
    num.times do 
        new_str += str
    end
    new_str
end

def yell(str)
    str.upcase + "!"
end

def alternating_case(str)
    array = []
    str.split(" ").each_with_index do |word, idx|
        if idx.even?
            array << word.upcase
        else
            array << word.downcase
        end
    end
    array.join(" ")
end