def hipsterfy(word)
    vowels = "aeiouAEIOU"
    rev_word = word.reverse
    rev_word.each_char.with_index do |char, idx|
        if vowels.include?(char)
            return (rev_word[0...idx] + rev_word[idx + 1..-1]).reverse
        end
    end
    word
end

def vowel_counts(str)
    hash = Hash.new(0)
    vowels = "aeiouAEIOU"
    str.each_char do |char|
        if vowels.include?(char)
            hash[char.downcase] += 1
        end
    end
    hash
end

def caesar_cipher(message, n)
    alphabet = ("a".."z").to_a
    new_str = ""
    message.each_char do |char|
        if alphabet.include?(char)
            current_index = alphabet.index(char)
            new_index = current_index + n
            new_str += alphabet[new_index % 26]
        else
            new_str += char
        end
    end
    new_str
end