def reverser(str, &block)
    block.call(str.reverse)
end

def word_changer(str, &block)
    str.split(" ").map {|word| block.call(word)}.join(" ")
end

def greater_proc_value(num, proc1, proc2)
    proc1.call(num) > proc2.call(num) ? proc1.call(num) : proc2.call(num)
end

def and_selector(arr, proc1, proc2)
    arr.select {|ele| proc1.call(ele) and proc2.call(ele)}
end

def alternating_mapper(arr, proc1, proc2)
    arr.map.with_index {|ele, idx| idx.even? ? proc1.call(ele) : proc2.call(ele)}
end