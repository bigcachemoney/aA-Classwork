module Slideable



    def diagonal_dirs
        #getter for DIAGONAL_DIRS
    end

    #return array of places a Piece can move
    def moves
        #create array to collect moves

        #iterate over each of the directions in which a slideable piee can move
        #use the Piece subclass' "#move dirs"

    end
end