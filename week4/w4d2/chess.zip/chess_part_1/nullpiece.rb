require_relative "piece.rb"


class NullPiece

end