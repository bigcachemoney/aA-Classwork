class ComputerPlayer

end