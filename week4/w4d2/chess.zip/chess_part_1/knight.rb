require_relative "piece.rb"
require_relative "stepable.rb"
class Knight
    include Stepable

end