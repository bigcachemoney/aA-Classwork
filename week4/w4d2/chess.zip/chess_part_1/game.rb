class Game
    def initialize

    end
end