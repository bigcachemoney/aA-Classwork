require_relative "piece.rb"


class Pawn

end