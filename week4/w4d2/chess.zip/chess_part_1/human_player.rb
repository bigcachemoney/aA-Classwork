class HumanPlayer

end