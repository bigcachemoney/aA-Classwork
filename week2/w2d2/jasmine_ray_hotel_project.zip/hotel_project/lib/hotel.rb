require_relative "room"
require 'byebug'
class Hotel
    attr_reader :rooms
    def initialize(name, hash)
        @name = name
        @rooms = {}
        hash.each do |room_name, specified_capacity|
            @rooms[room_name] = Room.new(specified_capacity)
        end 
    end

    def name
        @name.split(" ").map(&:capitalize).join(" ")
    end 

    def room_exists?(name)
        @rooms.has_key?(name) #true/false
    end
    
    def check_in(person, room_name)
        if self.room_exists?(room_name) #if true, add occupant(string)
            if @rooms[room_name].add_occupant(person)
                #@rooms[room_name] = @capacity=2, @occupants=[]
                p 'check in successfuls'
            else 
                p 'sorry, room is full'
            end 
        else
            p 'sorry, room does not exist'
        end
    end

    def has_vacancy?
        #room = {"basement":4, "attic":2}
        #@rooms.values = [4,2]
        #def full?
        #@occupants.length < @capacity ? false : true 
        #all rooms full -> false
        #at least 1 available -> true
        @rooms
            .any? {|room_name, cap| !@rooms[room_name].full?} #value is hash[key], else room_name is key name 
            #self. = hotel 
            # .any? {|bool| bool == true}
    end

    def list_rooms
        @rooms.each do |room_name, c|
            puts room_name + ".*" + @rooms[room_name].available_space.to_s 
        end

    end
end
