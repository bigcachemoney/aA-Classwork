require 'byebug'
class Flight
    attr_reader :passengers
    def initialize(flight_number, capacity) #string, num
        @flight_number = flight_number
        @capacity = capacity
        @passengers = []
    end

    def full?
        @capacity == @passengers.length ? true : false
        #method ? IF TRUE DO THIS : IF FALSE DO THIS
    end

    def board_passenger(passenger) #Instance
        if passenger.has_flight?(@flight_number) and !self.full?  
            @passengers << passenger
        end
    end

    def list_passengers
        passenger_name_array = []
        @passengers.each do |passenger|
            passenger_name_array << passenger.name
        end
             #<Passenger:0x00007faed20d44d0 @name="Rose", @flight_numbers=["AA128"]> #<Passenger:0x00007faed20d43b8 @name="Trevor", @flight_numbers=["AA128"]>
        passenger_name_array
    end

    def [](index) #num
        @passengers[index]
    end
    
    def <<(passenger)#instance
        self.board_passenger(passenger)
    end
end