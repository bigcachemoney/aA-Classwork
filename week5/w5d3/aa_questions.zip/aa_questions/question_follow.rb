class QuestionFollow
    def self.find_by_id(id)
        var = Questions
    end
end
