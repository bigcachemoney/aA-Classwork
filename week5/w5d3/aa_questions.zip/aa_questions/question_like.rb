class QuestionLike
    def self.find_by_id
    end
end