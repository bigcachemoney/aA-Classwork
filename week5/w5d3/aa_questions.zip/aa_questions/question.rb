class Question
    def self.find_by_id
    end

    def initialize()
        @id, @title, @body, @author_id 

    end
end