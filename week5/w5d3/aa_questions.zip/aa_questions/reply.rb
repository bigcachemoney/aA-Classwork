class Reply
    def self.find_by_id
    end

    def initialize
        @id
        @question_id
        @parent_id
        @user_id
        @Reply
    end
end